"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function EditBrand({ params }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const router = useRouter()

  useEffect(() => {
    fetchBrand()
  }, [])

  const fetchBrand = async () => {
    try {
      const response = await fetch(`/api/brands/${params.id}`)
      if (!response.ok) throw new Error("Failed to fetch brand")
      const brand = await response.json()
      setFormData(brand)
    } catch (error) {
      console.error("Error:", error)
      setError("Failed to fetch brand")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/brands/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) throw new Error("Failed to update brand")

      router.push("/brands")
      router.refresh()
    } catch (error) {
      console.error("Error:", error)
      setError("Failed to update brand")
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="p-4">Loading...</div>
  if (error) return <div className="p-4 text-red-500">{error}</div>

  return (
    <div className="container mx-auto px-4 py-8">
      <div>
        <div>
          <h2>Edit Brand</h2>
        </div>
        <p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name">Name *</label>
              <input id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>

            <div>
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={3}
                className="w-full p-2 border rounded"
              />
            </div>

            <div className="flex justify-end gap-4">
              <button type="button" variant="outline" onClick={() => router.back()}>
                Cancel
              </button>
              <button type="submit" disabled={loading}>
                {loading ? "Updating..." : "Update Brand"}
              </button>
            </div>
          </form>
        </p>
      </div>
    </div>
  )
}

