import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()

    // Get the original sale item details
    const saleItem = await db.get(
      `
      SELECT price, product_id
      FROM sale_items
      WHERE sale_id = ? AND product_id = ?
    `,
      [data.sale_id, data.product_id],
    )

    if (!saleItem) {
      throw new Error("Sale item not found")
    }

    // Create the return record
    const returnResult = await db.run(
      `
      INSERT INTO product_returns (
        sale_id, customer_id, product_id, 
        quantity, price, reason
      ) VALUES (?, ?, ?, ?, ?, ?)
    `,
      [data.sale_id, data.customer_id, data.product_id, data.quantity, saleItem.price, data.reason],
    )

    // Update the product stock
    await db.run(
      `
      UPDATE products 
      SET stock = stock + ? 
      WHERE id = ?
    `,
      [data.quantity, data.product_id],
    )

    // Calculate return amount
    const returnAmount = saleItem.price * data.quantity

    // Update the sale balance
    await db.run(
      `
      UPDATE sales 
      SET balance_due = balance_due - ? 
      WHERE id = ?
    `,
      [returnAmount, data.sale_id],
    )

    await db.run("COMMIT")

    return NextResponse.json({ id: returnResult.lastID })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to process return" }, { status: 500 })
  }
}

