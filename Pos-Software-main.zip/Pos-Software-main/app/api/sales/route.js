// import { NextResponse } from "next/server"
// import { openDb } from "@/lib/db"

// export async function POST(request) {
//   const db = await openDb()

//   try {
//     await db.run("BEGIN TRANSACTION")

//     const data = await request.json()

//     // Calculate balance due based on paid amount
//     const balanceDue = data.total - (data.amountReceived || 0)

//     // Create the sale record
//     const saleResult = await db.run(
//       `INSERT INTO sales (
//         customer_id, salesperson_id, warehouse_id,
//         total_amount, paid_amount, payment_method, 
//         payment_status, balance_due, tax, discount,
//         shipping, status, date
//       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
//       [
//         data.customer === "walk-in" ? null : data.customer,
//         data.salesperson_id,
//         data.warehouse_id,
//         data.total,
//         data.amountReceived || 0,
//         data.paymentMethod,
//         data.amountReceived >= data.total ? "paid" : "partial",
//         balanceDue,
//         data.tax || 0,
//         data.discount || 0,
//         data.shipping || 0,
//         "completed",
//         new Date().toISOString(),
//       ],
//     )

//     let totalProfit = 0

//     // Insert sale items and update stock
//     for (const item of data.items) {
//       const product = await db.get("SELECT cost_price FROM products WHERE id = ?", [item.id])
//       const itemProfit = (item.price - product.cost_price) * item.quantity
//       totalProfit += itemProfit

//       await db.run(
//         `INSERT INTO sale_items (
//           sale_id, product_id, quantity,
//           unit_price, tax, discount, total
//         ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
//         [saleResult.lastID, item.id, item.quantity, item.price, item.tax || 0, item.discount || 0, item.total],
//       )

//       // Update product stock
//       await db.run(
//         `UPDATE products 
//          SET stock = stock - ? 
//          WHERE id = ?`,
//         [item.quantity, item.id],
//       )
//     }

//     // Update the sale record with the calculated profit
//     await db.run("UPDATE sales SET profit = ? WHERE id = ?", [totalProfit, saleResult.lastID])

//     // Create customer ledger entries
//     if (data.customer && data.customer !== "walk-in") {
//       const currentBalance = await db.get(
//         `SELECT COALESCE(MAX(balance), 0) as balance 
//          FROM customer_ledger 
//          WHERE customer_id = ?`,
//         [data.customer],
//       )

//       const newBalance = currentBalance.balance + balanceDue

//       // Sale entry
//       await db.run(
//         `INSERT INTO customer_ledger (
//           customer_id, transaction_type, amount, 
//           balance, description, date, sale_id
//         ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
//         [
//           data.customer,
//           "sale",
//           data.total,
//           newBalance,
//           `Sale #${saleResult.lastID}`,
//           new Date().toISOString(),
//           saleResult.lastID,
//         ],
//       )

//       // Payment entry (if any payment was made)
//       if (data.amountReceived > 0) {
//         await db.run(
//           `INSERT INTO customer_ledger (
//             customer_id, transaction_type, amount, 
//             balance, description, date, sale_id
//           ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
//           [
//             data.customer,
//             "payment",
//             -data.amountReceived,
//             newBalance - data.amountReceived,
//             `Payment for Sale #${saleResult.lastID}`,
//             new Date().toISOString(),
//             saleResult.lastID,
//           ],
//         )
//       }
//     }

//     await db.run("COMMIT")

//     return NextResponse.json({
//       success: true,
//       saleId: saleResult.lastID,
//     })
//   } catch (error) {
//     await db.run("ROLLBACK")
//     console.error("Database Error:", error)
//     return NextResponse.json({ error: "Failed to process sale" }, { status: 500 })
//   }
// }

import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()
    console.log("Received sale data:", data)

    // Calculate balance due based on paid amount
    const balanceDue = data.total - data.paid_amount

    // Create the sale record
    const saleResult = await db.run(
      `INSERT INTO sales (
        customer_id, salesperson_id, warehouse_id,
        total_amount, paid_amount, payment_method, 
        payment_status, balance_due, tax, discount,
        shipping, status, date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.customer === "walk-in" ? null : data.customer,
        data.salesperson_id,
        data.warehouse_id,
        data.total,
        data.paid_amount, // Using paid_amount as deposit_amount
        data.payment_method,
        data.paid_amount >= data.total ? "paid" : "partial",
        balanceDue,
        data.tax,
        data.discount,
        data.shipping,
        "completed",
        new Date().toISOString(),
      ],
    )

    // Insert sale items and update stock
    for (const item of data.items) {
      await db.run(
        `INSERT INTO sale_items (
          sale_id, product_id, quantity,
          unit_price, tax, discount, total
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [saleResult.lastID, item.id, item.quantity, item.price, item.tax, item.discount, item.total],
      )

      // Update product stock
      await db.run(
        `UPDATE products 
         SET stock = stock - ? 
         WHERE id = ?`,
        [item.quantity, item.id],
      )
    }

    // Create customer ledger entry if customer is not walk-in
    if (data.customer && data.customer !== "walk-in") {
      const currentBalance = await db.get(
        `SELECT COALESCE(MAX(balance), 0) as balance 
         FROM customer_ledger 
         WHERE customer_id = ?`,
        [data.customer],
      )

      const newBalance = currentBalance.balance + balanceDue

      // Sale entry
      await db.run(
        `INSERT INTO customer_ledger (
          customer_id, transaction_type, amount, 
          balance, description, date
        ) VALUES (?, ?, ?, ?, ?, ?)`,
        [data.customer, "sale", data.total, newBalance, `Sale #${saleResult.lastID}`, new Date().toISOString()],
      )

      // Payment entry (if any payment was made)
      if (data.paid_amount > 0) {
        await db.run(
          `INSERT INTO customer_ledger (
            customer_id, transaction_type, amount, 
            balance, description, date
          ) VALUES (?, ?, ?, ?, ?, ?)`,
          [
            data.customer,
            "payment",
            -data.paid_amount,
            newBalance - data.paid_amount,
            `Payment for Sale #${saleResult.lastID}`,
            new Date().toISOString(),
          ],
        )
      }
    }

    await db.run("COMMIT")

    return NextResponse.json({
      success: true,
      saleId: saleResult.lastID,
    })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to process sale: " + error.message }, { status: 500 })
  }
}

export async function GET() {
  try {
    const db = await openDb();

    const sales = await db.all("SELECT * FROM sales");

    return NextResponse.json({ success: true, sales });
  } catch (error) {
    console.error("Database Error:", error);
    return NextResponse.json(
      { error: "Failed to fetch sales: " + error.message },
      { status: 500 }
    );
  }
}

