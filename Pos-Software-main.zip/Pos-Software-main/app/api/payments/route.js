import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()

    // Get the current sale information
    const sale = await db.get("SELECT * FROM sales WHERE id = ?", [data.sale_id])

    if (!sale) {
      throw new Error("Sale not found")
    }

    // Calculate the new balance
    const newBalanceDue = sale.balance_due - data.amount
    const newPaidAmount = sale.paid_amount + data.amount

    // Update the sale record
    await db.run(
      `UPDATE sales 
       SET balance_due = ?, 
           paid_amount = ?, 
           payment_status = ?
       WHERE id = ?`,
      [newBalanceDue, newPaidAmount, newBalanceDue <= 0 ? "paid" : "partial", data.sale_id],
    )

    // Create payment record
    const paymentResult = await db.run(
      `INSERT INTO payments (
        customer_id, amount, payment_method,
        reference, notes, date
      ) VALUES (?, ?, ?, ?, ?, ?)`,
      [sale.customer_id, data.amount, data.paymentMethod, data.reference, data.notes, new Date().toISOString()],
    )

    // Update customer ledger
    if (sale.customer_id) {
      const currentBalance = await db.get(
        `SELECT COALESCE(MAX(balance), 0) as balance 
         FROM customer_ledger 
         WHERE customer_id = ?`,
        [sale.customer_id],
      )

      const newBalance = currentBalance.balance - data.amount

      await db.run(
        `INSERT INTO customer_ledger (
          customer_id, transaction_type, amount, 
          balance, description, date, sale_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          sale.customer_id,
          "payment",
          -data.amount,
          newBalance,
          `Additional payment for Sale #${data.sale_id}`,
          new Date().toISOString(),
          data.sale_id,
        ],
      )
    }

    await db.run("COMMIT")

    return NextResponse.json({
      success: true,
      paymentId: paymentResult.lastID,
      newBalance: newBalanceDue,
    })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to process payment" }, { status: 500 })
  }
}

