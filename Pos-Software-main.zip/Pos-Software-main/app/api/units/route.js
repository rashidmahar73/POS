import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await openDb()
    const units = await db.all("SELECT * FROM units")
    return NextResponse.json({ units })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch units" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()

    const result = await db.run(
      `INSERT INTO units (name, short_name, base_unit, operator, operation_value) 
       VALUES (?, ?, ?, ?, ?)`,
      [data.name, data.short_name, data.base_unit, data.operator, data.operation_value],
    )

    return NextResponse.json({ id: result.lastID })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to add unit" }, { status: 500 })
  }
}

