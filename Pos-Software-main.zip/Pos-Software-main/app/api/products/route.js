import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"
import { writeFile, mkdir } from "fs/promises"
import { join, dirname } from "path"
import { fileURLToPath } from "url"

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const warehouse_id = searchParams.get("warehouse_id")

  try {
    const db = await openDb()
    let query = `
      SELECT 
        products.*,
        b.name as brand_name,
        c.name as category_name,
        u.name as unit_name,
        COALESCE(w.warehouse_stock, 0) as warehouse_stock
      FROM products
      LEFT JOIN brands b ON products.brand_id = b.id
      LEFT JOIN categories c ON products.category_id = c.id
      LEFT JOIN units u ON products.unit_id = u.id
    `

    const params = []

    if (warehouse_id) {
      query += `
        LEFT JOIN (
          SELECT product_id, SUM(quantity) as warehouse_stock 
          FROM stock_movements 
          WHERE warehouse_id = ?
          GROUP BY product_id
        ) w ON products.id = w.product_id
      `
      params.push(warehouse_id)
    } else {
      query = query.replace(
        "COALESCE(w.warehouse_stock, 0) as warehouse_stock",
        "(SELECT COALESCE(SUM(quantity), 0) FROM stock_movements WHERE product_id = products.id) as warehouse_stock",
      )
    }

    const products = await db.all(query, params)

    if (!products) {
      return NextResponse.json({ error: "No products found" }, { status: 404 })
    }

    return NextResponse.json({ products })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch products", details: error.message }, { status: 500 })
  }
}

export async function POST(request) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const formData = await request.formData()
    let imageUrl = null

    // Handle image upload if present
    const image = formData.get("image")
    if (image && image.size > 0) {
      const __dirname = dirname(fileURLToPath(import.meta.url))
      const imageDir = join(__dirname, "../../../public/images/products")

      // Create directory if it doesn't exist
      try {
        await mkdir(imageDir, { recursive: true })
      } catch (error) {
        if (error.code !== "EEXIST") throw error
      }

      const bytes = await image.arrayBuffer()
      const buffer = Buffer.from(bytes)
      const filename = `${Date.now()}-${image.name}`
      const imagePath = join(imageDir, filename)
      await writeFile(imagePath, buffer)
      imageUrl = `/images/products/${filename}`
    }

    // Insert product into database
    const result = await db.run(
      `INSERT INTO products (
        name, code, barcode_symbology, brand_id, 
        category_id, unit_id, purchase_unit_id, 
        sale_unit_id, cost, price, stock, 
        stock_alert, tax_type, tax, has_serial, 
        not_for_sale, description, image
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.get("name"),
        formData.get("code"),
        formData.get("barcode_symbology") || "code128",
        formData.get("brand_id") || null,
        formData.get("category_id") || null,
        formData.get("unit_id"),
        formData.get("purchase_unit_id") || null,
        formData.get("sale_unit_id") || null,
        formData.get("cost"),
        formData.get("price"),
        formData.get("stock") || 0,
        formData.get("stock_alert") || 0,
        formData.get("tax_type") || "exclusive",
        formData.get("tax") || 0,
        formData.get("has_serial") === "true" ? 1 : 0,
        formData.get("not_for_sale") === "true" ? 1 : 0,
        formData.get("description"),
        imageUrl,
      ],
    )

    await db.run("COMMIT")

    // Fetch the newly created product to return
    const product = await db.get("SELECT * FROM products WHERE id = ?", [result.lastID])
    return NextResponse.json(product)
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to create product", details: error.message }, { status: 500 })
  }
}

