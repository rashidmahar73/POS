import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"
import { writeFile, mkdir } from "fs/promises"
import { join, dirname } from "path"
import { fileURLToPath } from "url"

export async function GET(request, { params }) {
  try {
    const db = await openDb()
    const product = await db.get(
      `SELECT 
        products.*,
        b.name as brand_name,
        c.name as category_name,
        u.name as unit_name
      FROM products
      LEFT JOIN brands b ON products.brand_id = b.id
      LEFT JOIN categories c ON products.category_id = c.id
      LEFT JOIN units u ON products.unit_id = u.id
      WHERE products.id = ?`,
      [params.id],
    )

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(product)
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 })
  }
}

export async function PUT(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const formData = await request.formData()
    let imageUrl = formData.get("image")

    // Handle new image upload if present
    const image = formData.get("newImage")
    if (image && image.size > 0) {
      const __dirname = dirname(fileURLToPath(import.meta.url))
      const imageDir = join(__dirname, "../../../../../public/images/products")

      try {
        await mkdir(imageDir, { recursive: true })
      } catch (error) {
        if (error.code !== "EEXIST") throw error
      }

      const bytes = await image.arrayBuffer()
      const buffer = Buffer.from(bytes)
      const filename = `${Date.now()}-${image.name}`
      const imagePath = join(imageDir, filename)
      await writeFile(imagePath, buffer)
      imageUrl = `/images/products/${filename}`
    }

    const result = await db.run(
      `UPDATE products SET
        name = ?, code = ?, barcode_symbology = ?, brand_id = ?, 
        category_id = ?, unit_id = ?, purchase_unit_id = ?, 
        sale_unit_id = ?, cost = ?, price = ?, stock_alert = ?, 
        tax_type = ?, tax = ?, has_serial = ?, not_for_sale = ?, 
        description = ?, image = ?
        WHERE id = ?`,
      [
        formData.get("name"),
        formData.get("code"),
        formData.get("barcode_symbology"),
        formData.get("brand_id") || null,
        formData.get("category_id") || null,
        formData.get("unit_id"),
        formData.get("purchase_unit_id") || null,
        formData.get("sale_unit_id") || null,
        formData.get("cost"),
        formData.get("price"),
        formData.get("stock_alert") || 0,
        formData.get("tax_type"),
        formData.get("tax"),
        formData.get("has_serial") === "true" ? 1 : 0,
        formData.get("not_for_sale") === "true" ? 1 : 0,
        formData.get("description"),
        imageUrl,
        params.id,
      ],
    )

    await db.run("COMMIT")

    if (result.changes === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    const updatedProduct = await db.get("SELECT * FROM products WHERE id = ?", [params.id])
    return NextResponse.json(updatedProduct)
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const result = await db.run("DELETE FROM products WHERE id = ?", [params.id])

    if (result.changes === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    await db.run("COMMIT")
    return NextResponse.json({ success: true })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}

