import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()

    const result = await db.run(
      `INSERT INTO customers (name, email, phone, address, credit_limit) 
       VALUES (?, ?, ?, ?, ?)`,
      [data.name, data.email, data.phone, data.address, data.creditLimit || 0],
    )

    return NextResponse.json({ id: result.lastID })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to add customer" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const db = await openDb()
    const customers = await db.all("SELECT * FROM customers")
    return NextResponse.json({ customers })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 })
  }
}

