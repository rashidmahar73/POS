import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()
    const customerId = params.id

    // Get current balance
    const currentBalance = await db.get(
      `SELECT COALESCE(MAX(balance), 0) as balance 
       FROM customer_ledger 
       WHERE customer_id = ?`,
      [customerId],
    )

    const newBalance = currentBalance.balance - data.amount

    // Create payment record
    const paymentResult = await db.run(
      `INSERT INTO payments (
        customer_id, amount, payment_method,
        reference, notes, date
      ) VALUES (?, ?, ?, ?, ?, ?)`,
      [customerId, data.amount, data.paymentMethod, data.reference, data.notes, data.date || new Date().toISOString()],
    )

    // Create ledger entry for payment
    await db.run(
      `INSERT INTO customer_ledger (
        customer_id, transaction_type,
        amount, balance, description, date
      ) VALUES (?, ?, ?, ?, ?, ?)`,
      [
        customerId,
        "payment",
        -data.amount,
        newBalance,
        `Payment: ${data.notes || "Cash payment"}`,
        data.date || new Date().toISOString(),
      ],
    )

    await db.run("COMMIT")

    return NextResponse.json({
      success: true,
      paymentId: paymentResult.lastID,
      newBalance,
    })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to process payment" }, { status: 500 })
  }
}

