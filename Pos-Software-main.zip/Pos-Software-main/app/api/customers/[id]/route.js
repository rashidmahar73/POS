import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET(request, { params }) {
  try {
    const db = await openDb()
    const customer = await db.get("SELECT * FROM customers WHERE id = ?", [params.id])

    if (!customer) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 })
    }

    return NextResponse.json(customer)
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch customer" }, { status: 500 })
  }
}

export async function PUT(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()
    const result = await db.run(
      `UPDATE customers SET 
        name = ?, email = ?, phone = ?, 
        address = ?, credit_limit = ?
        WHERE id = ?`,
      [data.name, data.email, data.phone, data.address, data.credit_limit || 0, params.id],
    )

    if (result.changes === 0) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 })
    }

    await db.run("COMMIT")

    const updatedCustomer = await db.get("SELECT * FROM customers WHERE id = ?", [params.id])
    return NextResponse.json(updatedCustomer)
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to update customer" }, { status: 500 })
  }
}

export async function DELETE(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const result = await db.run("DELETE FROM customers WHERE id = ?", [params.id])

    if (result.changes === 0) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 })
    }

    await db.run("COMMIT")
    return NextResponse.json({ success: true })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to delete customer" }, { status: 500 })
  }
}

