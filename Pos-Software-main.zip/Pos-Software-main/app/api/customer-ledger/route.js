import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"
import ExcelJS from "exceljs"
import PDFDocument from "pdfkit"

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const customerId = searchParams.get("customerId")
  const format = searchParams.get("format")

  if (!customerId) {
    return NextResponse.json({ error: "Customer ID is required" }, { status: 400 })
  }

  try {
    const db = await openDb()
    const ledger = await db.all(`SELECT * FROM customer_ledger WHERE customer_id = ? ORDER BY date ASC`, [customerId])

    if (format === "excel") {
      const workbook = new ExcelJS.Workbook()
      const worksheet = workbook.addWorksheet("Customer Ledger")

      worksheet.columns = [
        { header: "Date", key: "date", width: 20 },
        { header: "Transaction Type", key: "transaction_type", width: 20 },
        { header: "Amount", key: "amount", width: 15 },
        { header: "Balance", key: "balance", width: 15 },
        { header: "Description", key: "description", width: 30 },
      ]

      worksheet.addRows(ledger)

      const buffer = await workbook.xlsx.writeBuffer()
      return new NextResponse(buffer, {
        status: 200,
        headers: {
          "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "Content-Disposition": `attachment; filename=customer_ledger_${customerId}.xlsx`,
        },
      })
    } else if (format === "pdf") {
      const doc = new PDFDocument()
      const buffers = []
      doc.on("data", buffers.push.bind(buffers))
      doc.on("end", () => {
        const pdfData = Buffer.concat(buffers)
        return new NextResponse(pdfData, {
          status: 200,
          headers: {
            "Content-Type": "application/pdf",
            "Content-Disposition": `attachment; filename=customer_ledger_${customerId}.pdf`,
          },
        })
      })

      doc.fontSize(18).text("Customer Ledger", { align: "center" })
      doc.moveDown()

      ledger.forEach((entry) => {
        doc.fontSize(12).text(`Date: ${entry.date}`)
        doc.fontSize(10).text(`Transaction Type: ${entry.transaction_type}`)
        doc.text(`Amount: ${entry.amount}`)
        doc.text(`Balance: ${entry.balance}`)
        doc.text(`Description: ${entry.description}`)
        doc.moveDown()
      })

      doc.end()
    } else {
      return NextResponse.json({ ledger })
    }
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch customer ledger" }, { status: 500 })
  }
}

