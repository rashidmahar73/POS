import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { openDb } from "@/lib/db"
import bcrypt from "bcryptjs"

export async function POST(request) {
  try {
    const { username, password } = await request.json()
    const db = await openDb()

    const user = await db.get("SELECT * FROM users WHERE username = ?", [username])
    if (!user) {
      return NextResponse.json({ message: "Invalid credentials" }, { status: 401 })
    }

    // For the first login with plain text password, hash it and update
    if (!user.password.startsWith("$2a$")) {
      const hashedPassword = await bcrypt.hash(user.password, 10)
      await db.run("UPDATE users SET password = ? WHERE id = ?", [hashedPassword, user.id])
      user.password = hashedPassword
    }

    const isValid = await bcrypt.compare(password, user.password)
    if (!isValid) {
      return NextResponse.json({ message: "Invalid credentials" }, { status: 401 })
    }

    const { password: _, ...userWithoutPassword } = user
    cookies().set({
      name: "session",
      value: JSON.stringify(userWithoutPassword),
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    })

    return NextResponse.json(userWithoutPassword)
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

