import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await openDb()

    const agingData = await db.all(`
      WITH aging AS (
        SELECT 
          c.id,
          c.name,
          s.total_amount,
          s.balance_due,
          CASE 
            WHEN julianday('now') - julianday(s.date) <= 0 THEN 'current'
            WHEN julianday('now') - julianday(s.date) <= 30 THEN '30'
            WHEN julianday('now') - julianday(s.date) <= 60 THEN '60'
            WHEN julianday('now') - julianday(s.date) <= 90 THEN '90'
            ELSE 'over_90'
          END as aging_period
        FROM customers c
        LEFT JOIN sales s ON c.id = s.customer_id
        WHERE s.balance_due > 0
      )
      SELECT 
        id,
        name,
        SUM(CASE WHEN aging_period = 'current' THEN balance_due ELSE 0 END) as current,
        SUM(CASE WHEN aging_period = '30' THEN balance_due ELSE 0 END) as days_30,
        SUM(CASE WHEN aging_period = '60' THEN balance_due ELSE 0 END) as days_60,
        SUM(CASE WHEN aging_period = '90' THEN balance_due ELSE 0 END) as days_90,
        SUM(CASE WHEN aging_period = 'over_90' THEN balance_due ELSE 0 END) as days_over_90
      FROM aging
      GROUP BY id, name
      HAVING current + days_30 + days_60 + days_90 + days_over_90 > 0
      ORDER BY name
    `)

    return NextResponse.json(agingData)
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch aging report" }, { status: 500 })
  }
}

