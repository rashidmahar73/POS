import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const start = searchParams.get("start")
    const end = searchParams.get("end")

    const db = await openDb()

    const commissionData = await db.all(
      `
      SELECT 
        u.id as salesperson_id,
        u.name as salesperson_name,
        u.commission_rate,
        SUM(s.total_amount) as total_sales,
        SUM(s.total_amount * (u.commission_rate / 100)) as commission_amount
      FROM users u
      LEFT JOIN sales s ON u.id = s.salesperson_id
      WHERE u.role = 'salesman'
        AND s.date BETWEEN ? AND ?
      GROUP BY u.id, u.name, u.commission_rate
      ORDER BY commission_amount DESC
    `,
      [start, end],
    )

    return NextResponse.json(commissionData)
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch commission report" }, { status: 500 })
  }
}

