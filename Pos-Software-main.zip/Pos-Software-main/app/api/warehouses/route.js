import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await openDb()
    const warehouses = await db.all("SELECT * FROM warehouses")
    return NextResponse.json({ warehouses })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch warehouses" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()

    const result = await db.run(
      `INSERT INTO warehouses (name, address, phone, email) 
       VALUES (?, ?, ?, ?)`,
      [data.name, data.address, data.phone, data.email],
    )

    return NextResponse.json({ id: result.lastID })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to add warehouse" }, { status: 500 })
  }
}

