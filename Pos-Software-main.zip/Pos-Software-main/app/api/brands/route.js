import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await openDb()
    const brands = await db.all("SELECT * FROM brands")
    return NextResponse.json({ brands })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch brands" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()

    const result = await db.run(
      `INSERT INTO brands (name, description) 
       VALUES (?, ?)`,
      [data.name, data.description],
    )

    return NextResponse.json({ id: result.lastID })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to add brand" }, { status: 500 })
  }
}

