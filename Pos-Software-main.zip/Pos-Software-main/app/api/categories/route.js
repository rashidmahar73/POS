import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await openDb()
    const categories = await db.all("SELECT * FROM categories")
    return NextResponse.json({ categories })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch categories" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()
    const result = await db.run("INSERT INTO categories (name, description) VALUES (?, ?)", [
      data.name,
      data.description,
    ])
    return NextResponse.json({ id: result.lastID })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to create category" }, { status: 500 })
  }
}

