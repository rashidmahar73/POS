import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function GET(request, { params }) {
  try {
    const db = await openDb()
    const supplier = await db.get("SELECT * FROM suppliers WHERE id = ?", [params.id])

    if (!supplier) {
      return NextResponse.json({ error: "Supplier not found" }, { status: 404 })
    }

    return NextResponse.json(supplier)
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch supplier" }, { status: 500 })
  }
}

export async function PUT(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()
    const result = await db.run(
      `UPDATE suppliers SET 
        name = ?, email = ?, phone = ?, address = ?
        WHERE id = ?`,
      [data.name, data.email, data.phone, data.address, params.id],
    )

    if (result.changes === 0) {
      return NextResponse.json({ error: "Supplier not found" }, { status: 404 })
    }

    await db.run("COMMIT")

    const updatedSupplier = await db.get("SELECT * FROM suppliers WHERE id = ?", [params.id])
    return NextResponse.json(updatedSupplier)
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to update supplier" }, { status: 500 })
  }
}

export async function DELETE(request, { params }) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const result = await db.run("DELETE FROM suppliers WHERE id = ?", [params.id])

    if (result.changes === 0) {
      return NextResponse.json({ error: "Supplier not found" }, { status: 404 })
    }

    await db.run("COMMIT")
    return NextResponse.json({ success: true })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to delete supplier" }, { status: 500 })
  }
}

