import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  try {
    const db = await openDb()
    const data = await request.json()

    // Start a transaction
    await db.run("BEGIN TRANSACTION")

    try {
      // Insert the purchase header
      const purchaseResult = await db.run(
        `INSERT INTO purchases (
          supplier_id, warehouse_id, tax, discount, shipping, 
          status, note, total_amount, date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          data.supplier_id,
          data.warehouse_id,
          data.tax,
          data.discount,
          data.shipping,
          data.status,
          data.note,
          data.grandTotal,
          data.date,
        ],
      )

      const purchaseId = purchaseResult.lastID

      // Insert purchase items and update product stock
      for (const item of data.items) {
        await db.run(
          `INSERT INTO purchase_items (
            purchase_id, product_id, quantity, unit_cost,
            discount, tax, subtotal
          ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [purchaseId, item.product_id, item.quantity, item.net_unit_cost, item.discount, item.tax, item.subtotal],
        )

        // Update product stock
        await db.run(
          `UPDATE products 
           SET stock = stock + ? 
           WHERE id = ?`,
          [item.quantity, item.product_id],
        )
      }

      // Commit the transaction
      await db.run("COMMIT")

      return NextResponse.json({ id: purchaseId })
    } catch (error) {
      // Rollback on error
      await db.run("ROLLBACK")
      throw error
    }
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to create purchase" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const db = await openDb()
    const purchases = await db.all(`
      SELECT p.*, s.name as supplier_name, w.name as warehouse_name
      FROM purchases p
      LEFT JOIN suppliers s ON p.supplier_id = s.id
      LEFT JOIN warehouses w ON p.warehouse_id = w.id
      ORDER BY p.date DESC
    `)
    return NextResponse.json({ purchases })
  } catch (error) {
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to fetch purchases" }, { status: 500 })
  }
}

