import { NextResponse } from "next/server"
import { openDb } from "@/lib/db"

export async function POST(request) {
  const db = await openDb()

  try {
    await db.run("BEGIN TRANSACTION")

    const data = await request.json()

    // Create stock movement record
    await db.run(
      `INSERT INTO stock_movements (
        product_id, warehouse_id, supplier_id,
        quantity, unit_cost, type, date
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [data.product_id, data.warehouse_id, data.supplier_id, data.quantity, data.unit_cost, "initial", data.date],
    )

    // Update product stock
    await db.run(
      `UPDATE products 
       SET stock = stock + ? 
       WHERE id = ?`,
      [data.quantity, data.product_id],
    )

    await db.run("COMMIT")

    return NextResponse.json({ success: true })
  } catch (error) {
    await db.run("ROLLBACK")
    console.error("Database Error:", error)
    return NextResponse.json({ error: "Failed to create stock entry" }, { status: 500 })
  }
}

