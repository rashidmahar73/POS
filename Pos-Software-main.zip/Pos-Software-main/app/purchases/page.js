"use client"

import Link from "next/link"
import { FileText, Plus, Upload } from "lucide-react"

export default function Purchases() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link
          href="/purchases/create"
          className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          <Plus className="w-6 h-6 mr-3 text-gray-600" />
          <span className="text-gray-800 font-medium">Create Purchase</span>
        </Link>

        <Link
          href="/purchases/all"
          className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          <FileText className="w-6 h-6 mr-3 text-gray-600" />
          <span className="text-gray-800 font-medium">All Purchases</span>
        </Link>

        <Link
          href="/purchases/import"
          className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          <Upload className="w-6 h-6 mr-3 text-gray-600" />
          <span className="text-gray-800 font-medium">Import Purchases</span>
        </Link>
      </div>
    </div>
  )
}

