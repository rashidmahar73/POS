"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"
import Link from "next/link"
export default function CreatePurchase() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split("T")[0],
    supplier_id: "",
    warehouse_id: "",
    tax: 0,
    discount: 0,
    shipping: 0,
    status: "received",
    note: "",
  })
  const [orderItems, setOrderItems] = useState([])
  const [suppliers, setSuppliers] = useState([])
  const [warehouses, setWarehouses] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [products, setProducts] = useState([])

  useEffect(() => {
    const fetchSuppliers = async () => {
      try {
        const response = await fetch("/api/suppliers")
        const data = await response.json()
        setSuppliers(data.suppliers)
      } catch (error) {
        console.error("Error fetching suppliers:", error)
      }
    }

    fetchSuppliers()
    // In a real app, fetch these from your API
    setWarehouses([
      { id: 1, name: "Warehouse 1" },
      { id: 2, name: "Warehouse 2" },
    ])
  }, [])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const addOrderItem = (product) => {
    setOrderItems((prev) => [
      ...prev,
      {
        product_id: product.id,
        product_name: product.name,
        net_unit_cost: product.purchase_price,
        current_stock: product.stock,
        quantity: 1,
        discount: 0,
        tax: 0,
        subtotal: product.purchase_price,
      },
    ])
  }

  const updateOrderItem = (index, field, value) => {
    setOrderItems((prev) => {
      const updated = [...prev]
      updated[index] = {
        ...updated[index],
        [field]: value,
        subtotal: calculateSubtotal(updated[index], field, value),
      }
      return updated
    })
  }

  const calculateSubtotal = (item, field, newValue) => {
    const quantity = field === "quantity" ? newValue : item.quantity
    const netUnitCost = field === "net_unit_cost" ? newValue : item.net_unit_cost
    const discount = field === "discount" ? newValue : item.discount
    const tax = field === "tax" ? newValue : item.tax

    const subtotal = quantity * netUnitCost
    const discountAmount = subtotal * (discount / 100)
    const taxAmount = (subtotal - discountAmount) * (tax / 100)

    return subtotal - discountAmount + taxAmount
  }

  const calculateTotals = () => {
    const subtotal = orderItems.reduce((sum, item) => sum + item.subtotal, 0)
    const taxAmount = subtotal * (formData.tax / 100)
    const discountAmount = subtotal * (formData.discount / 100)
    const shipping = Number.parseFloat(formData.shipping) || 0

    return {
      subtotal,
      tax: taxAmount,
      discount: discountAmount,
      shipping,
      grandTotal: subtotal + taxAmount - discountAmount + shipping,
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      const response = await fetch("/api/purchases", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          items: orderItems,
          ...calculateTotals(),
        }),
      })

      if (!response.ok) throw new Error("Failed to create purchase")

      router.push("/purchases")
    } catch (error) {
      console.error("Error:", error)
      alert("Failed to create purchase")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Create Purchase</h1>
        <div className="flex gap-2">
          <Link href="/purchases" className="text-blue-600 hover:text-blue-800">
            All Purchases
          </Link>
          <span className="text-gray-400">|</span>
          <span className="text-gray-600">Create Purchase</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date *</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
              required
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Supplier *</label>
            <select
              name="supplier_id"
              value={formData.supplier_id}
              onChange={handleInputChange}
              required
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Choose Supplier</option>
              {suppliers.map((supplier) => (
                <option key={supplier.id} value={supplier.id}>
                  {supplier.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Warehouse *</label>
            <select
              name="warehouse_id"
              value={formData.warehouse_id}
              onChange={handleInputChange}
              required
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Choose Warehouse</option>
              {warehouses.map((warehouse) => (
                <option key={warehouse.id} value={warehouse.id}>
                  {warehouse.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Product</label>
          <div className="flex items-center border rounded-md px-3 py-2">
            <Search className="w-5 h-5 text-gray-400 mr-2" />
            <input
              type="text"
              placeholder="Scan/Search Product by Code Or Name"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full outline-none"
            />
          </div>
        </div>

        <div className="mb-6 overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-2 text-left">#</th>
                <th className="px-4 py-2 text-left">Product</th>
                <th className="px-4 py-2 text-right">Net Unit Cost</th>
                <th className="px-4 py-2 text-right">Current Stock</th>
                <th className="px-4 py-2 text-right">Qty</th>
                <th className="px-4 py-2 text-right">Discount</th>
                <th className="px-4 py-2 text-right">Tax</th>
                <th className="px-4 py-2 text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {orderItems.length === 0 ? (
                <tr>
                  <td colSpan="8" className="px-4 py-2 text-center text-gray-500">
                    No data Available
                  </td>
                </tr>
              ) : (
                orderItems.map((item, index) => (
                  <tr key={index} className="border-b">
                    <td className="px-4 py-2">{index + 1}</td>
                    <td className="px-4 py-2">{item.product_name}</td>
                    <td className="px-4 py-2">
                      <input
                        type="number"
                        value={item.net_unit_cost}
                        onChange={(e) => updateOrderItem(index, "net_unit_cost", Number.parseFloat(e.target.value))}
                        className="w-24 text-right border rounded px-2 py-1"
                      />
                    </td>
                    <td className="px-4 py-2 text-right">{item.current_stock}</td>
                    <td className="px-4 py-2">
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateOrderItem(index, "quantity", Number.parseInt(e.target.value))}
                        className="w-20 text-right border rounded px-2 py-1"
                      />
                    </td>
                    <td className="px-4 py-2">
                      <input
                        type="number"
                        value={item.discount}
                        onChange={(e) => updateOrderItem(index, "discount", Number.parseFloat(e.target.value))}
                        className="w-20 text-right border rounded px-2 py-1"
                      />
                    </td>
                    <td className="px-4 py-2">
                      <input
                        type="number"
                        value={item.tax}
                        onChange={(e) => updateOrderItem(index, "tax", Number.parseFloat(e.target.value))}
                        className="w-20 text-right border rounded px-2 py-1"
                      />
                    </td>
                    <td className="px-4 py-2 text-right">RS {item.subtotal.toFixed(2)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Order Tax</label>
            <div className="flex">
              <input
                type="number"
                name="tax"
                value={formData.tax}
                onChange={handleInputChange}
                className="w-full border rounded-l-md px-3 py-2"
              />
              <span className="inline-flex items-center px-3 py-2 border border-l-0 rounded-r-md bg-gray-50">%</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Discount</label>
            <div className="flex">
              <input
                type="number"
                name="discount"
                value={formData.discount}
                onChange={handleInputChange}
                className="w-full border rounded-l-md px-3 py-2"
              />
              <span className="inline-flex items-center px-3 py-2 border border-l-0 rounded-r-md bg-gray-50">RS</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Shipping</label>
            <div className="flex">
              <input
                type="number"
                name="shipping"
                value={formData.shipping}
                onChange={handleInputChange}
                className="w-full border rounded-l-md px-3 py-2"
              />
              <span className="inline-flex items-center px-3 py-2 border border-l-0 rounded-r-md bg-gray-50">RS</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              required
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="received">Received</option>
              <option value="pending">Pending</option>
              <option value="ordered">Ordered</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
            <textarea
              name="note"
              value={formData.note}
              onChange={handleInputChange}
              placeholder="A few words ..."
              className="w-full border rounded-md px-3 py-2"
              rows="3"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}

