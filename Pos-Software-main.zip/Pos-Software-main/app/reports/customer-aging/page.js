"use client"

import { useState, useEffect } from "react"
import { format } from "date-fns"

export default function CustomerAging() {
  const [agingData, setAgingData] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAgingData()
  }, [])

  const fetchAgingData = async () => {
    try {
      const response = await fetch("/api/reports/customer-aging")
      const data = await response.json()
      setAgingData(data)
    } catch (error) {
      console.error("Error fetching aging data:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold mb-6">Customer Aging Report</h1>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Current</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">1-30 Days</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">31-60 Days</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">61-90 Days</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Over 90 Days</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {agingData.map((customer) => (
                <tr key={customer.id}>
                  <td className="px-6 py-4 whitespace-nowrap">{customer.name}</td>
                  <td className="px-6 py-4 text-right">{customer.current.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{customer.days_30.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{customer.days_60.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{customer.days_90.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{customer.days_over_90.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right font-semibold">
                    {(
                      customer.current +
                      customer.days_30 +
                      customer.days_60 +
                      customer.days_90 +
                      customer.days_over_90
                    ).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

