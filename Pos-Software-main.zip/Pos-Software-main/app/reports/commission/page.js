"use client"

import { useState, useEffect } from "react"
import { format } from "date-fns"

export default function CommissionReport() {
  const [commissionData, setCommissionData] = useState([])
  const [dateRange, setDateRange] = useState({
    start: format(new Date().setDate(1), "yyyy-MM-dd"),
    end: format(new Date(), "yyyy-MM-dd"),
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchCommissionData()
  }, []) // Removed unnecessary dateRange dependency

  const fetchCommissionData = async () => {
    try {
      const response = await fetch(`/api/reports/commission?start=${dateRange.start}&end=${dateRange.end}`)
      const data = await response.json()
      setCommissionData(data)
    } catch (error) {
      console.error("Error fetching commission data:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Salesperson Commission Report</h1>
        <div className="flex gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Start Date</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">End Date</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
        </div>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Salesperson</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total Sales</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Commission Rate</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Commission Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {commissionData.map((item) => (
                <tr key={item.salesperson_id}>
                  <td className="px-6 py-4 whitespace-nowrap">{item.salesperson_name}</td>
                  <td className="px-6 py-4 text-right">{item.total_sales.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{item.commission_rate}%</td>
                  <td className="px-6 py-4 text-right font-semibold">{item.commission_amount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

