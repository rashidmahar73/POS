"use client"

import { useState, useEffect } from "react"
import Link from "next/link"

export default function Customers() {
  const [customers, setCustomers] = useState([])
  useEffect(() => {
    fetchSCustomers()
  }, [])
  const fetchSCustomers = async () => {
    try {
      const response = await fetch("/api/customers")
      const data = await response.json()
      setCustomers(data.customers)
    } catch (error) {
      console.error("Error fetching suppliers:", error)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-4">Customers</h2>
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Name</th>
            <th className="py-2 px-4 border-b">Email</th>
            <th className="py-2 px-4 border-b">Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer.id}>
              <td className="py-2 px-4 border-b">{customer.name}</td>
              <td className="py-2 px-4 border-b">{customer.email}</td>
              <td className="py-2 px-4 border-b">
                <Link href={`/api/customer-ledger/${customer.id}`} className="text-blue-600 hover:text-blue-800">
                  Download Ledger
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

