"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function CustomerLedger({ params }) {
  const [ledger, setLedger] = useState([])
  const [customer, setCustomer] = useState(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentData, setPaymentData] = useState({
    amount: "",
    paymentMethod: "cash",
    reference: "",
    notes: "",
    date: new Date().toISOString().split("T")[0],
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const router = useRouter()

  useEffect(() => {
    fetchLedger()
    fetchCustomer()
  }, [])

  const fetchLedger = async () => {
    try {
      const response = await fetch(`/api/customer-ledger?customerId=${params.id}`)
      const data = await response.json()
      setLedger(data.ledger)
    } catch (error) {
      console.error("Error fetching ledger:", error)
      setError("Failed to fetch ledger")
    }
  }

  const fetchCustomer = async () => {
    try {
      const response = await fetch(`/api/customers/${params.id}`)
      const data = await response.json()
      setCustomer(data)
    } catch (error) {
      console.error("Error fetching customer:", error)
      setError("Failed to fetch customer details")
    }
  }

  const handlePaymentSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/customers/${params.id}/payments`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      if (!response.ok) throw new Error("Failed to process payment")

      await fetchLedger() // Refresh ledger data
      setShowPaymentModal(false)
      setPaymentData({
        amount: "",
        paymentMethod: "cash",
        reference: "",
        notes: "",
        date: new Date().toISOString().split("T")[0],
      })
    } catch (error) {
      console.error("Error:", error)
      setError("Failed to process payment")
    } finally {
      setLoading(false)
    }
  }

  const downloadLedger = async (format) => {
    try {
      const response = await fetch(`/api/customer-ledger?customerId=${params.id}&format=${format}`)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.style.display = "none"
      a.href = url
      a.download = `customer_ledger_${params.id}.${format}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error(`Error downloading ${format} ledger:`, error)
      setError(`Failed to download ${format} ledger`)
    }
  }

  if (!customer) return <div>Loading...</div>

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Customer Ledger: {customer.name}</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setShowPaymentModal(true)}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Add Payment
          </button>
          <button onClick={() => downloadLedger("excel")} className="px-4 py-2 border rounded hover:bg-gray-100">
            Download Excel
          </button>
          <button onClick={() => downloadLedger("pdf")} className="px-4 py-2 border rounded hover:bg-gray-100">
            Download PDF
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left p-4">Date</th>
                <th className="text-left p-4">Type</th>
                <th className="text-right p-4">Amount</th>
                <th className="text-right p-4">Balance</th>
                <th className="text-left p-4">Description</th>
              </tr>
            </thead>
            <tbody>
              {ledger.map((entry) => (
                <tr key={entry.id} className="border-t">
                  <td className="p-4">{new Date(entry.date).toLocaleDateString()}</td>
                  <td className="p-4">
                    <span
                      className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                        entry.transaction_type === "payment"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {entry.transaction_type}
                    </span>
                  </td>
                  <td className="p-4 text-right">RS {Math.abs(entry.amount).toFixed(2)}</td>
                  <td className="p-4 text-right">RS {entry.balance.toFixed(2)}</td>
                  <td className="p-4">{entry.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add Payment</h2>
            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium mb-1">
                  Amount
                </label>
                <input
                  id="amount"
                  type="number"
                  step="0.01"
                  required
                  value={paymentData.amount}
                  onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                  className="w-full p-2 border rounded"
                />
              </div>

              <div>
                <label htmlFor="paymentMethod" className="block text-sm font-medium mb-1">
                  Payment Method
                </label>
                <select
                  id="paymentMethod"
                  value={paymentData.paymentMethod}
                  onChange={(e) => setPaymentData({ ...paymentData, paymentMethod: e.target.value })}
                  className="w-full p-2 border rounded"
                >
                  <option value="cash">Cash</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="cheque">Cheque</option>
                </select>
              </div>

              <div>
                <label htmlFor="date" className="block text-sm font-medium mb-1">
                  Date
                </label>
                <input
                  id="date"
                  type="date"
                  required
                  value={paymentData.date}
                  onChange={(e) => setPaymentData({ ...paymentData, date: e.target.value })}
                  className="w-full p-2 border rounded"
                />
              </div>

              <div>
                <label htmlFor="reference" className="block text-sm font-medium mb-1">
                  Reference
                </label>
                <input
                  id="reference"
                  type="text"
                  value={paymentData.reference}
                  onChange={(e) => setPaymentData({ ...paymentData, reference: e.target.value })}
                  placeholder="Cheque number, transaction ID, etc."
                  className="w-full p-2 border rounded"
                />
              </div>

              <div>
                <label htmlFor="notes" className="block text-sm font-medium mb-1">
                  Notes
                </label>
                <textarea
                  id="notes"
                  value={paymentData.notes}
                  onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                  rows="3"
                  className="w-full p-2 border rounded"
                />
              </div>

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 border rounded hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
                >
                  {loading ? "Processing..." : "Add Payment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

