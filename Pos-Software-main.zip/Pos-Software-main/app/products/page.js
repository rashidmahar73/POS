"use client"

import { useState, useEffect } from "react"
import Link from "next/link"

export default function Products() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/products")
      const data = await response.json()
      console.log("products api response", data)
      setProducts(data.products)
    } catch (error) {
      console.error("Error fetching products:", error)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-4">Products</h2>
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Name</th>
            <th className="py-2 px-4 border-b">Price</th>
            <th className="py-2 px-4 border-b">Stock</th>
            <th className="py-2 px-4 border-b">Brand</th>
            <th className="py-2 px-4 border-b">Category</th>
            <th className="py-2 px-4 border-b">Unit</th>
            <th className="py-2 px-4 border-b">Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td className="py-2 px-4 border-b">{product.name}</td>
              <td className="py-2 px-4 border-b">${product.price.toFixed(2)}</td>
              <td className="py-2 px-4 border-b">{product.warehouse_stock || 0}</td>
              <td className="py-2 px-4 border-b">{product.brand_name || "N/A"}</td>
              <td className="py-2 px-4 border-b">{product.category_name || "N/A"}</td>
              <td className="py-2 px-4 border-b">{product.unit_name || "N/A"}</td>
              <td className="py-2 px-4 border-b">
                <Link href={`/products/${product.id}`} className="text-blue-600 hover:text-blue-800">
                  Edit
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

