"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function EditProduct({ params }) {
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    barcode_symbology: "code128",
    brand_id: "",
    category_id: "",
    unit_id: "",
    purchase_unit_id: "",
    sale_unit_id: "",
    cost: "",
    price: "",
    stock_alert: 0,
    tax_type: "exclusive",
    tax: "0",
    has_serial: false,
    not_for_sale: false,
    description: "",
    image: null,
  })

  const [brands, setBrands] = useState([])
  const [categories, setCategories] = useState([])
  const [units, setUnits] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const router = useRouter()

  useEffect(() => {
    fetchProduct()
    fetchOptions()
  }, [params]) // Updated dependency array

  const fetchProduct = async () => {
    try {
      const response = await fetch(`/api/products/${params.id}`)
      if (!response.ok) throw new Error("Failed to fetch product")
      const product = await response.json()
      setFormData(product)
    } catch (error) {
      console.error("Error:", error)
      setError("Failed to fetch product")
    }
  }

  const fetchOptions = async () => {
    try {
      const [brandsRes, categoriesRes, unitsRes] = await Promise.all([
        fetch("/api/brands").then((res) => res.json()),
        fetch("/api/categories").then((res) => res.json()),
        fetch("/api/units").then((res) => res.json()),
      ])
      setBrands(brandsRes.brands)
      setCategories(categoriesRes.categories)
      setUnits(unitsRes.units)
    } catch (error) {
      console.error("Error fetching options:", error)
      setError("Failed to fetch form options")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : type === "file" ? files[0] : value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const formDataToSend = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        if (key !== "newImage") {
          formDataToSend.append(key, value)
        }
      })

      // If there's a new image, append it
      if (formData.newImage) {
        formDataToSend.append("newImage", formData.newImage)
      }

      const response = await fetch(`/api/products/${params.id}`, {
        method: "PUT",
        body: formDataToSend,
      })

      if (!response.ok) throw new Error("Failed to update product")

      router.push("/products")
      router.refresh()
    } catch (error) {
      console.error("Error:", error)
      setError("Failed to update product")
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="p-4">Loading...</div>
  if (error) return <div className="p-4 text-red-500">{error}</div>

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-6">Edit Product</h2>
      <form onSubmit={handleSubmit} className="max-w-4xl bg-white rounded-lg shadow p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
            <input
              type="text"
              name="name"
              required
              value={formData.name}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Code *</label>
            <input
              type="text"
              name="code"
              required
              value={formData.code}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
            <select
              name="brand_id"
              value={formData.brand_id || ""}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Select Brand</option>
              {brands.map((brand) => (
                <option key={brand.id} value={brand.id}>
                  {brand.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              name="category_id"
              value={formData.category_id || ""}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Select Category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Unit *</label>
            <select
              name="unit_id"
              required
              value={formData.unit_id || ""}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Select Unit</option>
              {units.map((unit) => (
                <option key={unit.id} value={unit.id}>
                  {unit.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Purchase Unit</label>
            <select
              name="purchase_unit_id"
              value={formData.purchase_unit_id || ""}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Select Purchase Unit</option>
              {units.map((unit) => (
                <option key={unit.id} value={unit.id}>
                  {unit.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sale Unit</label>
            <select
              name="sale_unit_id"
              value={formData.sale_unit_id || ""}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="">Select Sale Unit</option>
              {units.map((unit) => (
                <option key={unit.id} value={unit.id}>
                  {unit.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cost Price *</label>
            <input
              type="number"
              name="cost"
              required
              step="0.01"
              value={formData.cost}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Selling Price *</label>
            <input
              type="number"
              name="price"
              required
              step="0.01"
              value={formData.price}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Stock Alert</label>
            <input
              type="number"
              name="stock_alert"
              value={formData.stock_alert}
              onChange={handleChange}
              min="0"
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tax Type</label>
            <select
              name="tax_type"
              value={formData.tax_type}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="exclusive">Exclusive</option>
              <option value="inclusive">Inclusive</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tax Rate (%)</label>
            <input
              type="number"
              name="tax"
              value={formData.tax}
              onChange={handleChange}
              min="0"
              step="0.01"
              className="w-full border rounded-md px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Product Image</label>
            {formData.image && (
              <div className="mb-2">
                <Image
                  src={formData.image || "/placeholder.svg"}
                  alt="Current product image"
                  width={100}
                  height={100}
                  className="rounded-md"
                />
              </div>
            )}
            <input
              type="file"
              name="newImage"
              onChange={handleChange}
              accept="image/*"
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="has_serial"
              name="has_serial"
              checked={formData.has_serial}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600"
            />
            <label htmlFor="has_serial" className="ml-2 text-sm text-gray-700">
              Product Has IMEI/Serial Number
            </label>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="not_for_sale"
              name="not_for_sale"
              checked={formData.not_for_sale}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600"
            />
            <label htmlFor="not_for_sale" className="ml-2 text-sm text-gray-700">
              This Product Not For Selling
            </label>
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea
            name="description"
            value={formData.description || ""}
            onChange={handleChange}
            rows="3"
            className="w-full border rounded-md px-3 py-2"
          />
        </div>

        <div className="mt-6 flex justify-end gap-4">
          <button type="button" onClick={() => router.back()} className="px-4 py-2 border rounded-md hover:bg-gray-50">
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? "Updating..." : "Update Product"}
          </button>
        </div>
      </form>
    </div>
  )
}

