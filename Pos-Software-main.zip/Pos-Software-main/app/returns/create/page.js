"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function CreateReturn() {
  const [formData, setFormData] = useState({
    sale_id: "",
    customer_id: "",
    product_id: "",
    quantity: 1,
    reason: "",
  })
  const [sales, setSales] = useState([])
  const [selectedSale, setSelectedSale] = useState(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    fetchSales()
  }, [])

  const fetchSales = async () => {
    try {
      const response = await fetch("/api/sales")
      const data = await response.json()
      setSales(data.sales)
    } catch (error) {
      console.error("Error fetching sales:", error)
    }
  }

  const handleSaleChange = async (saleId) => {
    try {
      const response = await fetch(`/api/sales/${saleId}`)
      const data = await response.json()
      setSelectedSale(data)
      setFormData((prev) => ({
        ...prev,
        sale_id: saleId,
        customer_id: data.customer_id,
      }))
    } catch (error) {
      console.error("Error fetching sale details:", error)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/returns", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) throw new Error("Failed to create return")

      router.push("/returns")
    } catch (error) {
      console.error("Error:", error)
      alert("Failed to create return")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-6">Create Product Return</h2>
      <form onSubmit={handleSubmit} className="max-w-lg bg-white rounded-lg shadow p-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Select Sale</label>
            <select
              value={formData.sale_id}
              onChange={(e) => handleSaleChange(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
              required
            >
              <option value="">Choose a sale</option>
              {sales.map((sale) => (
                <option key={sale.id} value={sale.id}>
                  Sale #{sale.id} - {sale.date}
                </option>
              ))}
            </select>
          </div>

          {selectedSale && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700">Select Product</label>
                <select
                  value={formData.product_id}
                  onChange={(e) => setFormData({ ...formData, product_id: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                  required
                >
                  <option value="">Choose a product</option>
                  {selectedSale.items.map((item) => (
                    <option key={item.product_id} value={item.product_id}>
                      {item.product_name} (Qty: {item.quantity})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Quantity</label>
                <input
                  type="number"
                  min="1"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: Number.parseInt(e.target.value) })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Reason</label>
                <textarea
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  rows="3"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                  required
                />
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? "Processing..." : "Submit Return"}
          </button>
        </div>
      </form>
    </div>
  )
}

