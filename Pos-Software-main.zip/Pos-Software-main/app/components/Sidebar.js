import Link from "next/link"

export default function Sidebar() {
  return (
    <div className="bg-gray-800 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out">
      <nav>
        <Link href="/" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
          Dashboard
        </Link>
        <Link href="/pos" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
          POS
        </Link>
        <div className="py-2.5 px-4">
          <span className="font-semibold">Products</span>
          <Link href="/products" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            All Products
          </Link>
          <Link href="/products/add" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Add Product
          </Link>
          <Link href="/categories" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Categories
          </Link>
          <Link href="/categories/add" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Add Category
          </Link>
          <Link href="/brands" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Brands
          </Link>
          <Link href="/brands/add" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Add Brand
          </Link>
          <Link href="/units" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Units
          </Link>
          <Link href="/units/add" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Add Unit
          </Link>
        </div>
        <div className="py-2.5 px-4">
          <span className="font-semibold">Inventory</span>
          <Link href="/warehouses" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Warehouses
          </Link>
          <Link href="/warehouses/add" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Add Warehouse
          </Link>
        </div>
        <Link href="/customers" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
          Customers
        </Link>
        <Link href="/suppliers" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700">
          Suppliers
        </Link>
        <div className="py-2.5 px-4">
          <span className="font-semibold">Transactions</span>
          <Link href="/purchases" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Purchases
          </Link>
          <Link href="/sales" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Sales
          </Link>
          <Link href="/returns" className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700">
            Returns
          </Link>
        </div>
        <div className="py-2.5 px-4">
          <span className="font-semibold">Reports</span>
          <Link
            href="/reports/customer-aging"
            className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700"
          >
            Customer Aging
          </Link>
          <Link
            href="/reports/commission"
            className="block pl-4 py-2 rounded transition duration-200 hover:bg-gray-700"
          >
            Commission
          </Link>
        </div>
      </nav>
    </div>
  )
}

