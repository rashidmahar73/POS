export default function Receipt({ sale, onPrint }) {
    return (
      <div className="bg-white p-8 max-w-md mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold">Invoice POS</h2>
          <img src="/logo.png" alt="Company Logo" className="mx-auto w-24 my-4" />
          <p>Date: {new Date().toLocaleDateString()}</p>
          <p>Address: Muhammad Pur Diwan</p>
          <p>Email: Admin@Example.Com</p>
          <p>Phone: 03357875740</p>
          <p>Customer: {sale.customer || "Walk-In-Customer"}</p>
          <p>Warehouse: HZ</p>
        </div>
  
        <div className="border-t border-b py-4 my-4">
          {sale.items.map((item, index) => (
            <div key={index} className="flex justify-between">
              <div>
                <p>{item.name}</p>
                <p className="text-sm text-gray-600">
                  {item.quantity} CT X {item.price}
                </p>
              </div>
              <p>{(item.quantity * item.price).toFixed(2)}</p>
            </div>
          ))}
        </div>
  
        <div className="space-y-2">
          <div className="flex justify-between">
            <p>Order Tax</p>
            <p>
              PKR {sale.tax.toFixed(2)} ({sale.taxRate}%)
            </p>
          </div>
          <div className="flex justify-between">
            <p>Discount</p>
            <p>PKR {sale.discount.toFixed(2)}</p>
          </div>
          <div className="flex justify-between">
            <p>Shipping</p>
            <p>PKR {sale.shipping.toFixed(2)}</p>
          </div>
          <div className="flex justify-between font-bold">
            <p>Grand Total</p>
            <p>PKR {sale.total.toFixed(2)}</p>
          </div>
        </div>
  
        <div className="mt-4 pt-4 border-t">
          <div className="grid grid-cols-3 text-sm">
            <div>
              <p>Paid By:</p>
              <p>{sale.paymentMethod}</p>
            </div>
            <div>
              <p>Amount:</p>
              <p>{sale.amountPaid.toFixed(2)}</p>
            </div>
            <div>
              <p>Change Return:</p>
              <p>{sale.changeReturn.toFixed(2)}</p>
            </div>
          </div>
        </div>
  
        <div className="text-center mt-6">
          <p className="font-medium">Thank You For Shopping With Us .</p>
          <p>Please Come Again</p>
          <div className="mt-4">
            <img src={`data:image/png;base64,${sale.barcode}`} alt="Sale Barcode" className="mx-auto" />
            <p className="text-sm">SL_{sale.id}</p>
          </div>
        </div>
  
        <div className="mt-4">
          <button onClick={onPrint} className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600">
            Print
          </button>
        </div>
      </div>
    )
  }
  
  