"use client"

import { useState, useEffect } from "react"

export default function Dashboard() {
  const [salesData, setSalesData] = useState(null)

  useEffect(() => {
    fetch("/api/sales")
      .then((response) => response.json())
      .then((data) => setSalesData(data))
      .catch((error) => console.error("Error fetching sales data:", error))
  }, [])

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>
      {salesData ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-2">Total Sales</h3>
            <p className="text-3xl font-bold">${salesData.totalSales}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-2">Net Profit</h3>
            <p className="text-3xl font-bold">${salesData.netProfit}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-2">Top Customer</h3>
            <p className="text-xl">{salesData.topCustomer}</p>
          </div>
        </div>
      ) : (
        <p>Loading dashboard data...</p>
      )}
    </div>
  )
}

