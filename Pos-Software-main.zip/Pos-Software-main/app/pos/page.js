// "use client"

// import { useState, useEffect } from "react"
// import { useRouter } from "next/navigation"
// import Image from "next/image"
// import { Search } from "lucide-react"
// import PaymentModal from "./components/PaymentModal"

// export default function POS() {
//   const [products, setProducts] = useState([])
//   const [cart, setCart] = useState([])
//   const [total, setTotal] = useState(0)
//   const [customers, setCustomers] = useState([])
//   const [warehouses, setWarehouses] = useState([])
//   const [selectedCustomer, setSelectedCustomer] = useState("")
//   const [selectedWarehouse, setSelectedWarehouse] = useState("")
//   const [searchTerm, setSearchTerm] = useState("")
//   const [showPaymentModal, setShowPaymentModal] = useState(false)
//   const [formData, setFormData] = useState({ tax: 0, discount: 0, shipping: 0 })
//   const [user, setUser] = useState(null)
//   const [error, setError] = useState(null) // Added error state
//   const router = useRouter()

//   useEffect(() => {
//     fetchCustomers()
//     fetchWarehouses()
//   }, [])

//   useEffect(() => {
//     if (selectedWarehouse) {
//       fetchProducts()
//     }
//   }, [selectedWarehouse])

//   const fetchCustomers = async () => {
//     try {
//       const response = await fetch("/api/customers")
//       const data = await response.json()
//       setCustomers(data.customers)
//     } catch (error) {
//       console.error("Error fetching customers:", error)
//     }
//   }

//   const fetchWarehouses = async () => {
//     try {
//       const response = await fetch("/api/warehouses")
//       const data = await response.json()
//       setWarehouses(data.warehouses)
//     } catch (error) {
//       console.error("Error fetching warehouses:", error)
//     }
//   }

//   const fetchProducts = async () => {
//     try {
//       setError(null)
//       const response = await fetch(`/api/products?warehouse_id=${selectedWarehouse}`)
//       const data = await response.json()

//       if (!response.ok) {
//         throw new Error(data.error || "Failed to fetch products")
//       }

//       setProducts(data.products || [])
//     } catch (error) {
//       console.error("Error fetching products:", error)
//       setError(error.message || "Failed to load products. Please try again later.")
//     }
//   }

//   useEffect(() => {
//     const { grandTotal } = calculateTotals()
//     setTotal(grandTotal)
//   }, [cart, formData])

//   useEffect(() => {
//     const sessionUser = JSON.parse(localStorage.getItem("user"))
//     if (sessionUser) {
//       setUser(sessionUser)
//     } else {
//       router.push("/login")
//     }
//   }, [router])

//   const addToCart = (product) => {
//     const existingItem = cart.find((item) => item.id === product.id)
//     const currentQty = existingItem?.quantity || 0
//     const remainingStock = product.warehouse_stock - currentQty

//     if (remainingStock <= 0) {
//       return // Don't add if no stock remaining
//     }

//     if (existingItem) {
//       updateCartItem(product.id, "quantity", currentQty + 1)
//     } else {
//       setCart([...cart, { ...product, quantity: 1, total: product.price, tax: 0, discount: 0 }])
//     }
//   }

//   const removeFromCart = (productId) => {
//     setCart(cart.filter((item) => item.id !== productId))
//   }

//   const updateQuantity = (productId, newQuantity) => {
//     if (newQuantity < 1) return

//     const product = products.find((p) => p.id === productId)
//     if (!product) return

//     const remainingStock = product.warehouse_stock - (cart.find((item) => item.id === productId)?.quantity || 0)
//     if (newQuantity > remainingStock + (cart.find((item) => item.id === productId)?.quantity || 0)) {
//       return // Don't update if exceeding available stock
//     }

//     updateCartItem(productId, "quantity", newQuantity)
//   }

//   const handlePayment = (method) => {
//     const { grandTotal } = calculateTotals()
//     const paidAmount = Number.parseFloat(prompt("Enter the amount paid:", grandTotal.toFixed(2))) || 0
//     const remainingBalance = grandTotal - paidAmount

//     const saleData = {
//       customer: selectedCustomer,
//       items: cart,
//       total: grandTotal,
//       paid_amount: paidAmount,
//       payment_method: method,
//       salesperson_id: user.id,
//       warehouse_id: selectedWarehouse,
//       tax: formData.tax,
//       discount: formData.discount,
//       shipping: formData.shipping,
//     }
//     console.log("Sale data",saleData)

//     // Send saleData to API
//     fetch("/api/sales", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//        body: JSON.stringify(saleData),
//     })
//       .then((response) => response.json())
//       .then((data) => {
//         if (data.success) {
//           alert(`Sale completed. Remaining balance: ${remainingBalance.toFixed(2)}`)
//           setCart([])
//           setFormData({ tax: 0, discount: 0, shipping: 0 })
//         } else {
//           alert("Error processing sale")
//         }
//       })
//       .catch((error) => {
//         console.error("Error:", error)
//         alert("Error processing sale")
//       })
//   }

//   const calculateItemTotal = (item) => {
//     const baseTotal = item.price * item.quantity
//     const discountAmount = ((item.discount || 0) / 100) * baseTotal
//     const afterDiscount = baseTotal - discountAmount
//     const taxAmount = ((item.tax || 0) / 100) * afterDiscount
//     return afterDiscount + taxAmount
//   }

//   const updateCartItem = (productId, field, value) => {
//     setCart(
//       cart.map((item) => {
//         if (item.id === productId) {
//           const updatedItem = { ...item, [field]: value }
//           updatedItem.total = calculateItemTotal(updatedItem)
//           return updatedItem
//         }
//         return item
//       }),
//     )
//   }

//   const calculateTotals = () => {
//     const subtotal = cart.reduce((sum, item) => sum + calculateItemTotal(item), 0)
//     const orderTax = ((formData.tax || 0) / 100) * subtotal
//     const orderDiscount = Number.parseFloat(formData.discount) || 0
//     const shipping = Number.parseFloat(formData.shipping) || 0

//     return {
//       subtotal,
//       tax: orderTax,
//       discount: orderDiscount,
//       shipping,
//       grandTotal: subtotal + orderTax - orderDiscount + shipping,
//     }
//   }

//   const handleFormDataChange = (e) => {
//     const { name, value } = e.target
//     setFormData({ ...formData, [name]: value })
//   }

//   // Add this to handle payment completion
//   const handlePaymentComplete = (result) => {
//     setCart([])
//     setShowPaymentModal(false)
//     // You might want to show a success message or redirect
//   }

//   if (!user) {
//     return <div>Loading...</div>
//   }

//   return (
//     <div className="flex h-screen bg-gray-100">
//       {/* Products Section */}
//       <div className="flex-1 p-4 overflow-auto">
//         <div className="mb-4 space-y-4">
//           <div className="flex gap-4">
//             <select
//               className="w-1/2 p-2 border rounded"
//               value={selectedCustomer}
//               onChange={(e) => setSelectedCustomer(e.target.value)}
//             >
//               <option value="">Select Customer</option>
//               <option value="walk-in">Walk-in Customer</option>
//               {customers.map((customer) => (
//                 <option key={customer.id} value={customer.id}>
//                   {customer.name}
//                 </option>
//               ))}
//             </select>

//             <select
//               className="w-1/2 p-2 border rounded"
//               value={selectedWarehouse}
//               onChange={(e) => setSelectedWarehouse(e.target.value)}
//             >
//               <option value="">Select Warehouse</option>
//               {warehouses.map((warehouse) => (
//                 <option key={warehouse.id} value={warehouse.id}>
//                   {warehouse.name}
//                 </option>
//               ))}
//             </select>
//           </div>

//           <div className="flex items-center bg-white rounded-lg p-2">
//             <Search className="w-5 h-5 text-gray-400 mr-2" />
//             <input
//               type="text"
//               placeholder="Scan/Search Product by Code Or Name"
//               className="w-full outline-none"
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//             />
//           </div>
//         </div>

//         {selectedWarehouse && error && (
//           <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
//             <strong className="font-bold">Error: </strong>
//             <span className="block sm:inline">{error}</span>
//           </div>
//         )}

//         {selectedWarehouse ? (
//           <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
//             {products
//               .filter(
//                 (product) =>
//                   product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//                   product.code.toLowerCase().includes(searchTerm.toLowerCase()),
//               )
//               .map((product) => {
//                 // Calculate remaining stock after cart items
//                 const cartItem = cart.find((item) => item.id === product.id)
//                 const remainingStock = product.warehouse_stock - (cartItem?.quantity || 0)

//                 return (
//                   <div
//                     key={product.id}
//                     className="bg-white p-4 rounded-lg shadow cursor-pointer"
//                     onClick={() => (remainingStock > 0 ? addToCart(product) : null)}
//                   >
//                     <Image
//                       src={product.image || "/placeholder.svg"}
//                       alt={product.name}
//                       width={200}
//                       height={200}
//                       className="w-full h-40 object-cover mb-2 rounded"
//                     />
//                     <div className="text-sm text-gray-600">{product.code}</div>
//                     <div className="font-semibold">{product.name}</div>
//                     <div className="text-blue-600">RS {product.price.toFixed(2)}</div>
//                     <div className={`text-sm ${remainingStock > 0 ? "text-gray-500" : "text-red-500"}`}>
//                       {remainingStock} in stock
//                     </div>
//                   </div>
//                 )
//               })}
//           </div>
//         ) : (
//           <div className="text-center text-gray-500 mt-8">Please select a warehouse to view products</div>
//         )}
//       </div>

//       {/* Cart Section */}
//       <div className="w-96 bg-white shadow-lg p-4 flex flex-col">
//         <div className="mb-4">{/* Removed the customer select as it's handled above */}</div>

//         <div className="flex-1 overflow-auto">
//           {cart.map((item) => (
//             <div key={item.id} className="flex justify-between items-center mb-2 p-2 border-b">
//               <div>
//                 <div className="font-semibold">{item.name}</div>
//                 <div className="text-sm text-gray-600">RS {item.total.toFixed(2)}</div>
//               </div>
//               <div className="flex items-center">
//                 <button
//                   className="px-2 py-1 bg-gray-200 rounded"
//                   onClick={() => updateQuantity(item.id, item.quantity - 1)}
//                 >
//                   -
//                 </button>
//                 <span className="mx-2">{item.quantity}</span>
//                 <button
//                   className="px-2 py-1 bg-gray-200 rounded"
//                   onClick={() => updateQuantity(item.id, item.quantity + 1)}
//                 >
//                   +
//                 </button>
//                 <button className="ml-2 text-red-500" onClick={() => removeFromCart(item.id)}>
//                   ×
//                 </button>
//               </div>
//             </div>
//           ))}
//         </div>

//         <div className="border-t pt-4">
//           <div className="flex justify-between mb-2">
//             <span>Subtotal:</span>
//             <span>RS {calculateTotals().subtotal.toFixed(2)}</span>
//           </div>
//           <div className="flex justify-between mb-2">
//             <span>Tax:</span>
//             <input
//               type="number"
//               name="tax"
//               value={formData.tax}
//               onChange={handleFormDataChange}
//               className="w-20 border rounded p-1 text-right"
//               placeholder="0%"
//             />
//           </div>
//           <div className="flex justify-between mb-2">
//             <span>Discount:</span>
//             <input
//               type="number"
//               name="discount"
//               value={formData.discount}
//               onChange={handleFormDataChange}
//               className="w-20 border rounded p-1 text-right"
//               placeholder="0.00"
//             />
//           </div>
//           <div className="flex justify-between mb-2">
//             <span>Shipping:</span>
//             <input
//               type="number"
//               name="shipping"
//               value={formData.shipping}
//               onChange={handleFormDataChange}
//               className="w-20 border rounded p-1 text-right"
//               placeholder="0.00"
//             />
//           </div>
//           <div className="flex justify-between font-bold text-lg mb-4">
//             <span>Total:</span>
//             <span>RS {total.toFixed(2)}</span>
//           </div>
//           <button
//             className="w-full bg-blue-500 text-white py-2 rounded-lg mb-2"
//             onClick={handlePayment} // Updated onClick handler
//             disabled={cart.length === 0}
//           >
//             Pay Now
//           </button>
//         </div>
//       </div>

//       {/* Payment Modal */}
//       {showPaymentModal && (
//         <PaymentModal
//           isOpen={showPaymentModal}
//           onClose={() => setShowPaymentModal(false)}
//           sale={{
//             items: cart,
//             total,
//             tax: calculateTotals().tax,
//             taxRate: formData.tax,
//             discount: calculateTotals().discount,
//             shipping: calculateTotals().shipping,
//             customer: selectedCustomer,
//           }}
//           onComplete={handlePaymentComplete}
//         />
//       )}
//     </div>
//   )
// }

"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Search } from "lucide-react"
import PaymentModal from "./components/PaymentModal"

export default function POS() {
  const [products, setProducts] = useState([])
  const [cart, setCart] = useState([])
  const [total, setTotal] = useState(0)
  const [customers, setCustomers] = useState([])
  const [warehouses, setWarehouses] = useState([])
  const [selectedCustomer, setSelectedCustomer] = useState("")
  const [selectedWarehouse, setSelectedWarehouse] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [formData, setFormData] = useState({ tax: 0, discount: 0, shipping: 0 })
  const [user, setUser] = useState(null)
  const [error, setError] = useState(null)
  const router = useRouter()

  useEffect(() => {
    fetchCustomers()
    fetchWarehouses()
  }, [])

  useEffect(() => {
    if (selectedWarehouse) {
      fetchProducts()
    }
  }, [selectedWarehouse])

  const fetchCustomers = async () => {
    try {
      const response = await fetch("/api/customers")
      const data = await response.json()
      setCustomers(data.customers)
    } catch (error) {
      console.error("Error fetching customers:", error)
    }
  }

  const fetchWarehouses = async () => {
    try {
      const response = await fetch("/api/warehouses")
      const data = await response.json()
      setWarehouses(data.warehouses)
    } catch (error) {
      console.error("Error fetching warehouses:", error)
    }
  }

  const fetchProducts = async () => {
    try {
      setError(null)
      const response = await fetch(`/api/products?warehouse_id=${selectedWarehouse}`)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to fetch products")
      }

      setProducts(data.products || [])
    } catch (error) {
      console.error("Error fetching products:", error)
      setError(error.message || "Failed to load products. Please try again later.")
    }
  }

  useEffect(() => {
    const { grandTotal } = calculateTotals()
    setTotal(grandTotal)
  }, [cart, formData])

  useEffect(() => {
    const sessionUser = JSON.parse(localStorage.getItem("user"))
    if (sessionUser) {
      setUser(sessionUser)
    } else {
      router.push("/login")
    }
  }, [router])

  const addToCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id)
    const currentQty = existingItem?.quantity || 0
    const remainingStock = product.warehouse_stock - currentQty

    if (remainingStock <= 0) {
      return
    }

    if (existingItem) {
      updateCartItem(product.id, "quantity", currentQty + 1)
    } else {
      setCart([...cart, { ...product, quantity: 1, total: product.price, tax: 0, discount: 0 }])
    }
  }

  const removeFromCart = (productId) => {
    setCart(cart.filter((item) => item.id !== productId))
  }

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity < 1) return

    const product = products.find((p) => p.id === productId)
    if (!product) return

    const remainingStock = product.warehouse_stock - (cart.find((item) => item.id === productId)?.quantity || 0)
    if (newQuantity > remainingStock + (cart.find((item) => item.id === productId)?.quantity || 0)) {
      return
    }

    updateCartItem(productId, "quantity", newQuantity)
  }

  const handlePayment = (method) => {
    const { grandTotal, subtotal, tax, discount, shipping } = calculateTotals()
    const paidAmount = Number.parseFloat(prompt("Enter the amount paid:", grandTotal.toFixed(2))) || 0
    const remainingBalance = grandTotal - paidAmount

    const saleData = {
      customer: selectedCustomer,
      items: cart.map((item) => ({
        id: item.id,
        quantity: item.quantity,
        price: item.price,
        total: item.total,
        tax: item.tax || 0,
        discount: item.discount || 0,
      })),
      total: grandTotal,
      subtotal: subtotal,
      paid_amount: paidAmount,
      payment_method: method,
      salesperson_id: user.id,
      warehouse_id: selectedWarehouse,
      tax: tax,
      discount: discount,
      shipping: shipping,
    }
    console.log("Sale data", saleData)

    fetch("/api/sales", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(saleData),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        return response.json()
      })
      .then((data) => {
        if (data.success) {
          alert(`Sale completed. Sale ID: ${data.saleId}. Remaining balance: ${remainingBalance.toFixed(2)}`)
          setCart([])
          setFormData({ tax: 0, discount: 0, shipping: 0 })
        } else {
          alert("Error processing sale: " + (data.error || "Unknown error"))
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        alert("Error processing sale: " + error.message)
      })
  }

  const calculateItemTotal = (item) => {
    const baseTotal = item.price * item.quantity
    const discountAmount = ((item.discount || 0) / 100) * baseTotal
    const afterDiscount = baseTotal - discountAmount
    const taxAmount = ((item.tax || 0) / 100) * afterDiscount
    return afterDiscount + taxAmount
  }

  const updateCartItem = (productId, field, value) => {
    setCart(
      cart.map((item) => {
        if (item.id === productId) {
          const updatedItem = { ...item, [field]: value }
          updatedItem.total = calculateItemTotal(updatedItem)
          return updatedItem
        }
        return item
      }),
    )
  }

  const calculateTotals = () => {
    const subtotal = cart.reduce((sum, item) => sum + calculateItemTotal(item), 0)
    const orderTax = ((formData.tax || 0) / 100) * subtotal
    const orderDiscount = Number.parseFloat(formData.discount) || 0
    const shipping = Number.parseFloat(formData.shipping) || 0

    return {
      subtotal,
      tax: orderTax,
      discount: orderDiscount,
      shipping,
      grandTotal: subtotal + orderTax - orderDiscount + shipping,
    }
  }

  const handleFormDataChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handlePaymentComplete = (result) => {
    setCart([])
    setShowPaymentModal(false)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <div className="flex-1 p-4 overflow-auto">
        <div className="mb-4 space-y-4">
          <div className="flex gap-4">
            <select
              className="w-1/2 p-2 border rounded"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
            >
              <option value="">Select Customer</option>
              <option value="walk-in">Walk-in Customer</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </select>

            <select
              className="w-1/2 p-2 border rounded"
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target.value)}
            >
              <option value="">Select Warehouse</option>
              {warehouses.map((warehouse) => (
                <option key={warehouse.id} value={warehouse.id}>
                  {warehouse.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center bg-white rounded-lg p-2">
            <Search className="w-5 h-5 text-gray-400 mr-2" />
            <input
              type="text"
              placeholder="Scan/Search Product by Code Or Name"
              className="w-full outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {selectedWarehouse && error && (
          <div className="bg-red-50 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        {selectedWarehouse ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products
              .filter(
                (product) =>
                  product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  product.code.toLowerCase().includes(searchTerm.toLowerCase()),
              )
              .map((product) => {
                const cartItem = cart.find((item) => item.id === product.id)
                const remainingStock = product.warehouse_stock - (cartItem?.quantity || 0)

                return (
                  <div
                    key={product.id}
                    className="bg-white p-4 rounded-lg shadow cursor-pointer"
                    onClick={() => (remainingStock > 0 ? addToCart(product) : null)}
                  >
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="w-full h-40 object-cover mb-2 rounded"
                    />
                    <div className="text-sm text-gray-600">{product.code}</div>
                    <div className="font-semibold">{product.name}</div>
                    <div className="text-blue-600">RS {product.price.toFixed(2)}</div>
                    <div className={`text-sm ${remainingStock > 0 ? "text-gray-500" : "text-red-500"}`}>
                      {remainingStock} in stock
                    </div>
                  </div>
                )
              })}
          </div>
        ) : (
          <div className="text-center text-gray-500 mt-8">Please select a warehouse to view products</div>
        )}
      </div>

      <div className="w-96 bg-white shadow-lg p-4 flex flex-col">
        <div className="mb-4"></div>

        <div className="flex-1 overflow-auto">
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between items-center mb-2 p-2 border-b">
              <div>
                <div className="font-semibold">{item.name}</div>
                <div className="text-sm text-gray-600">RS {item.total.toFixed(2)}</div>
              </div>
              <div className="flex items-center">
                <button
                  className="px-2 py-1 bg-gray-200 rounded"
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                >
                  -
                </button>
                <span className="mx-2">{item.quantity}</span>
                <button
                  className="px-2 py-1 bg-gray-200 rounded"
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                >
                  +
                </button>
                <button className="ml-2 text-red-500" onClick={() => removeFromCart(item.id)}>
                  ×
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t pt-4">
          <div className="flex justify-between mb-2">
            <span>Subtotal:</span>
            <span>RS {calculateTotals().subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Tax:</span>
            <input
              type="number"
              name="tax"
              value={formData.tax}
              onChange={handleFormDataChange}
              className="w-20 border rounded p-1 text-right"
              placeholder="0%"
            />
          </div>
          <div className="flex justify-between mb-2">
            <span>Discount:</span>
            <input
              type="number"
              name="discount"
              value={formData.discount}
              onChange={handleFormDataChange}
              className="w-20 border rounded p-1 text-right"
              placeholder="0.00"
            />
          </div>
          <div className="flex justify-between mb-2">
            <span>Shipping:</span>
            <input
              type="number"
              name="shipping"
              value={formData.shipping}
              onChange={handleFormDataChange}
              className="w-20 border rounded p-1 text-right"
              placeholder="0.00"
            />
          </div>
          <div className="flex justify-between font-bold text-lg mb-4">
            <span>Total:</span>
            <span>RS {total.toFixed(2)}</span>
          </div>
          <button
            className="w-full bg-blue-500 text-white py-2 rounded-lg mb-2"
            onClick={() => handlePayment("cash")}
            disabled={cart.length === 0}
          >
            Pay Now
          </button>
        </div>
      </div>

      {showPaymentModal && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          sale={{
            items: cart,
            total,
            tax: calculateTotals().tax,
            taxRate: formData.tax,
            discount: calculateTotals().discount,
            shipping: calculateTotals().shipping,
            customer: selectedCustomer,
          }}
          onComplete={handlePaymentComplete}
        />
      )}
    </div>
  )
}



