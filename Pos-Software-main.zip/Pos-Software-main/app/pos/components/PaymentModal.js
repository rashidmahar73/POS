"use client"

import { useState } from "react"
import { Dialog } from "@headlessui/react"

import Receipt from "@/app/components/Receipt"

export default function PaymentModal({ isOpen, onClose, sale, onComplete }) {
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [amountReceived, setAmountReceived] = useState(sale.total.toString())
  const [changeReturn, setChangeReturn] = useState("0")
  const [showReceipt, setShowReceipt] = useState(false)
  const [paymentNotes, setPaymentNotes] = useState("")
  const [loading, setLoading] = useState(false)

  const handleAmountChange = (e) => {
    const amount = Number.parseFloat(e.target.value) || 0
    setAmountReceived(e.target.value)
    setChangeReturn((amount - sale.total).toFixed(2))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const paymentData = {
        items: sale.items.map((item) => ({
          id: item.id,
          quantity: item.quantity,
          price: item.price,
          total: item.total,
        })),
        customer: sale.customer,
        total: sale.total,
        amountReceived: Number.parseFloat(amountReceived),
        paymentMethod,
        changeReturn: Number.parseFloat(changeReturn),
        paymentNotes,
        tax: sale.tax,
        discount: sale.discount,
        shipping: sale.shipping,
      }

      const response = await fetch("/api/sales", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      if (!response.ok) throw new Error("Failed to process sale")

      const result = await response.json()
      setShowReceipt(true)
      onComplete(result)
    } catch (error) {
      console.error("Error:", error)
      alert("Failed to process payment")
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  if (showReceipt) {
    return (
      <Dialog open={true} onOpenChange={() => onClose()}>
        <div className="p-6">
          <Receipt
            sale={{
              ...sale,
              paymentMethod,
              amountPaid: Number.parseFloat(amountReceived),
            }}
            onPrint={() => window.print()}
          />
        </div>
      </Dialog>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
      <div className="fixed inset-0 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <h2 className="text-xl font-bold mb-4">Payment</h2>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label>Payment Method</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full p-2 border rounded mt-1"
                >
                  <option value="cash">Cash</option>
                  <option value="credit">Credit</option>
                  <option value="card">Card</option>
                  <option value="bank">Bank Transfer</option>
                </select>
              </div>

              <div>
                <label>Amount Received</label>
                <input
                  type="number"
                  value={amountReceived}
                  onChange={handleAmountChange}
                  step="0.01"
                  className="mt-1"
                />
              </div>

              <div>
                <label>Change Return</label>
                <input type="text" value={changeReturn} readOnly className="mt-1 bg-gray-50" />
              </div>

              <div>
                <label>Payment Notes</label>
                <textarea
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  rows="3"
                  className="w-full p-2 border rounded mt-1"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button variant="outline" onClick={onClose}>
                Cancel
              </button>
              <button type="submit" disabled={loading}>
                {loading ? "Processing..." : "Complete Payment"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </Dialog>
  )
}

