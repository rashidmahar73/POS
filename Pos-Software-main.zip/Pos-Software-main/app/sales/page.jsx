"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link"

const Sales = () => {
  const [products, setProducts] = useState([]);
  console.log(products, "products");
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/sales");
      const data = await response.json();
      console.log("products api response", data);
      setProducts(data.sales);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };
  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-semibold mb-4">Sales Details</h2>
      <table className="min-w-full bg-white border">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b">Sale ID</th>
            <th className="py-2 px-4 border-b">Customer ID</th>
            <th className="py-2 px-4 border-b">Total Amount</th>
            <th className="py-2 px-4 border-b">Paid Amount</th>
            <th className="py-2 px-4 border-b">Balance Due</th>
            <th className="py-2 px-4 border-b">Payment Method</th>
            <th className="py-2 px-4 border-b">Payment Status</th>
            <th className="py-2 px-4 border-b">Salesperson ID</th>
            <th className="py-2 px-4 border-b">Warehouse ID</th>
            <th className="py-2 px-4 border-b">Tax</th>
            <th className="py-2 px-4 border-b">Discount</th>
            <th className="py-2 px-4 border-b">Shipping</th>
            <th className="py-2 px-4 border-b">Status</th>
            <th className="py-2 px-4 border-b">Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((sale) => (
            <tr key={sale.id}>
              <td className="py-2 px-4 border-b">{sale.id}</td>
              <td className="py-2 px-4 border-b">{sale.customer_id || "-"}</td>
              <td className="py-2 px-4 border-b">
                ${sale.total_amount.toFixed(2)}
              </td>
              <td className="py-2 px-4 border-b">
                ${sale.paid_amount.toFixed(2)}
              </td>
              <td className="py-2 px-4 border-b">
                ${sale.balance_due.toFixed(2)}
              </td>
              <td className="py-2 px-4 border-b">
                {sale.payment_method || "-"}
              </td>
              <td className="py-2 px-4 border-b">
                {sale.payment_status || "-"}
              </td>
              <td className="py-2 px-4 border-b">
                {sale.salesperson_id || "-"}
              </td>
              <td className="py-2 px-4 border-b">{sale.warehouse_id || "-"}</td>
              <td className="py-2 px-4 border-b">${sale.tax.toFixed(2)}</td>
              <td className="py-2 px-4 border-b">
                ${sale.discount.toFixed(2)}
              </td>
              <td className="py-2 px-4 border-b">{sale.shipping || "-"}</td>
              <td className="py-2 px-4 border-b">{sale.status || "-"}</td>
              <td className="py-2 px-4 border-b">
                <Link href={`/sales/${sale.id}`} className="text-blue-600 hover:text-blue-800">
                  Edit
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Sales;
